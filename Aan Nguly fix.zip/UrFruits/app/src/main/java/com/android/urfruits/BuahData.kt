package com.android.urfruits

data class BuahData(
    val nama: String,
    val desc: String,
    val pictureResource: Int
)
